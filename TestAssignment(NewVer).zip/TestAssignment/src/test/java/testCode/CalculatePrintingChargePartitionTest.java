package testCode;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import ApplicationCode.printerAvailability;
import ApplicationCode.applyDiscount;
import ApplicationCode.printOrder;
import ApplicationCode.calculatePrintingCharge;
import ApplicationCode.customer;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyDouble;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@RunWith(MockitoJUnitRunner.class)
public class CalculatePrintingChargePartitionTest {

    @Mock
    private printerAvailability printerServiceMock;

    @Mock
    private applyDiscount discountServiceMock;

    @Mock
    private printOrder orderMock;

    @Mock
    private customer customerMock; // Declared explicitly to fix the variable resolution error

    private calculatePrintingCharge calculator;

    @Before
    public void setUp() {
        calculator = new calculatePrintingCharge(printerServiceMock, discountServiceMock);

        // Default valid behavior across tests
        when(printerServiceMock.isPrinterAvailable(anyString(), anyString())).thenReturn(true);
        when(orderMock.getCustomer()).thenReturn(customerMock);
        
        // Default valid page/copy count so validateOrder() passes unless specifically testing boundaries
        when(orderMock.getNumberOfPages()).thenReturn(10);
        when(orderMock.getNumberOfCopies()).thenReturn(1);
        
        // Default optional services
        when(orderMock.getBindingOption()).thenReturn(null);
        when(orderMock.hasLamination()).thenReturn(false);
        when(orderMock.hasExpressPrinting()).thenReturn(false);
    }
    
    // ==========================================
    // 3. EQUIVALENCE PARTITIONING - PAPER SIZES & RATES
    // ==========================================

    @Test
    public void testPartition_A3_Colour_DoubleSided() {
        when(orderMock.getPaperSize()).thenReturn("A3");
        when(orderMock.getPrintType()).thenReturn("Colour");
        when(orderMock.getPrintingSide()).thenReturn("Double-sided");
        when(orderMock.getNumberOfPages()).thenReturn(10);
        when(orderMock.getNumberOfCopies()).thenReturn(2);
        when(discountServiceMock.calculateDiscount(any(), anyDouble())).thenReturn(0.0);

        double total = calculator.calculateTotal(orderMock);
        assertEquals(28.00, total, 0.001);
    }

    @Test
    public void testPartition_A5_BW_DoubleSided() {
        when(orderMock.getPaperSize()).thenReturn("A5");
        when(orderMock.getPrintType()).thenReturn("Black & White");
        when(orderMock.getPrintingSide()).thenReturn("Double-sided");
        when(orderMock.getNumberOfPages()).thenReturn(10);
        when(orderMock.getNumberOfCopies()).thenReturn(1);
        when(discountServiceMock.calculateDiscount(any(), anyDouble())).thenReturn(0.0);

        double total = calculator.calculateTotal(orderMock);
        assertEquals(1.30, total, 0.001);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testPartition_InvalidPaperSize_B5() {
        when(orderMock.getPaperSize()).thenReturn("B5");
        when(orderMock.getPrintType()).thenReturn("Colour");
        when(orderMock.getPrintingSide()).thenReturn("Single-sided");

        calculator.calculateTotal(orderMock);
    }

    // ==========================================
    // 4. EQUIVALENCE PARTITIONING - SERVICES & DISCOUNT
    // ==========================================

    @Test
    public void testPartition_AllServicesAndDiscount() {
        when(orderMock.getPaperSize()).thenReturn("A4");
        when(orderMock.getPrintType()).thenReturn("Colour");
        when(orderMock.getPrintingSide()).thenReturn("Single-sided");
        when(orderMock.getNumberOfPages()).thenReturn(10);
        when(orderMock.getNumberOfCopies()).thenReturn(2);

        when(orderMock.getBindingOption()).thenReturn("Spiral");
        when(orderMock.hasLamination()).thenReturn(true);
        when(orderMock.hasExpressPrinting()).thenReturn(true);

        when(discountServiceMock.calculateDiscount(customerMock, 74.00)).thenReturn(10.00);

        double total = calculator.calculateTotal(orderMock);
        assertEquals(64.00, total, 0.001);

        verify(orderMock).setBasePrintingCharge(16.00);
        verify(orderMock).setAdditionalServiceCharges(58.00);
        verify(orderMock).setDiscountAmount(10.00);
        verify(orderMock).setTotalPrintingCharge(64.00);
    }

    @Test(expected = IllegalStateException.class)
    public void testPartition_PrinterUnavailable() {
        when(orderMock.getPaperSize()).thenReturn("A4");
        when(orderMock.getPrintType()).thenReturn("Colour");
        
        when(printerServiceMock.isPrinterAvailable("A4", "Colour")).thenReturn(false);

        calculator.calculateTotal(orderMock);
    }
}