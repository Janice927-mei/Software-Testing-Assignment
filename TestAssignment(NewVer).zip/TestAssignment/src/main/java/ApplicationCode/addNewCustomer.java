package ApplicationCode;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class addNewCustomer {

	private String filePath;

    public addNewCustomer(String testFilePath) {
        this.filePath = testFilePath;
    }

    public void addCustomer(customer newCustomer) throws IOException {
        if (newCustomer == null) {
            throw new IllegalArgumentException("Customer cannot be null.");
        }
        PrintWriter writer = new PrintWriter(new FileWriter(filePath, true));

        writer.println(newCustomer.toString());
        writer.close();
    }
}